import csv
from datetime import datetime

# File to store expenses
FILENAME = "expenses.csv"

# Ensure the CSV file has headers
def initialize_csv():
    try:
        with open(FILENAME, 'x', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(["Date", "Category", "Description", "Amount"])
    except FileExistsError:
        pass

# Add a new expense
def add_expense():
    date = input("Enter date (YYYY-MM-DD) or press Enter for today: ").strip()
    if not date:
        date = datetime.now().strftime("%Y-%m-%d")

    category = input("Enter category (e.g., Food, Travel, Shopping): ").title()
    description = input("Enter description: ")
    amount = float(input("Enter amount: "))

    with open(FILENAME, 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([date, category, description, amount])
    print("✅ Expense added successfully!\n")

# View all expenses
def view_expenses():
    with open(FILENAME, 'r') as file:
        reader = csv.reader(file)
        next(reader)  # skip header
        print("\n--- All Expenses ---")
        for row in reader:
            print(f"{row[0]} | {row[1]} | {row[2]} | ₹{row[3]}")
    print()

# Search by category
def search_by_category():
    category = input("Enter category to search: ").title()
    total = 0
    found = False

    with open(FILENAME, 'r') as file:
        reader = csv.reader(file)
        next(reader)
        print(f"\n--- Expenses in {category} ---")
        for row in reader:
            if row[1] == category:
                found = True
                print(f"{row[0]} | {row[2]} | ₹{row[3]}")
                total += float(row[3])

    if found:
        print(f"Total spent in {category}: ₹{total}\n")
    else:
        print("No expenses found in this category.\n")

# Calculate total per category
def total_per_category():
    totals = {}
    with open(FILENAME, 'r') as file:
        reader = csv.reader(file)
        next(reader)
        for row in reader:
            category = row[1]
            amount = float(row[3])
            totals[category] = totals.get(category, 0) + amount

    print("\n--- Total Spent per Category ---")
    for category, total in totals.items():
        print(f"{category}: ₹{total}")
    print()

# Calculate monthly total
def monthly_total():
    totals = {}
    with open(FILENAME, 'r') as file:
        reader = csv.reader(file)
        next(reader)
        for row in reader:
            date = datetime.strptime(row[0], "%Y-%m-%d")
            month = date.strftime("%Y-%m")
            amount = float(row[3])
            totals[month] = totals.get(month, 0) + amount

    print("\n--- Monthly Spending ---")
    for month, total in totals.items():
        print(f"{month}: ₹{total}")
    print()

# Main menu
def main():
    initialize_csv()
    while True:
        print("========= Expense Tracker 2.0 =========")
        print("1. Add Expense")
        print("2. View All Expenses")
        print("3. Search by Category")
        print("4. Total Spent per Category")
        print("5. Monthly Spending")
        print("6. Exit")
        choice = input("Choose an option: ")

        if choice == '1':
            add_expense()
        elif choice == '2':
            view_expenses()
        elif choice == '3':
            search_by_category()
        elif choice == '4':
            total_per_category()
        elif choice == '5':
            monthly_total()
        elif choice == '6':
            print("👋 Exiting... Goodbye!")
            break
        else:
            print("Invalid choice! Try again.\n")

if __name__ == "__main__":
    main()
